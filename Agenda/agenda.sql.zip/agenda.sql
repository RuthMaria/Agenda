-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Mai 22, 2012 as 01:49 
-- Versão do Servidor: 5.1.37
-- Versão do PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `agenda`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `compromissos`
--

CREATE TABLE IF NOT EXISTS `compromissos` (
  `tipo` varchar(100) NOT NULL,
  `data` varchar(11) NOT NULL,
  `hora` time NOT NULL,
  `prioridade` varchar(20) NOT NULL,
  `id_compromisso` bigint(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_compromisso`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `compromissos`
--

INSERT INTO `compromissos` (`tipo`, `data`, `hora`, `prioridade`, `id_compromisso`) VALUES
('Aniversario', '09/05/2012', '17:00:00', 'baixa', 4),
('Formatura', '22/01/2012', '20:00:00', 'alta', 5),
('Prova de POOB', '13/12/2011', '15:50:00', 'alta', 6),
('Natal', '25/12/2011', '00:00:00', 'media', 7);

-- --------------------------------------------------------

--
-- Estrutura da tabela `contatos`
--

CREATE TABLE IF NOT EXISTS `contatos` (
  `nome` varchar(50) NOT NULL,
  `fone` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `id_contato` bigint(11) NOT NULL AUTO_INCREMENT,
  `grupo` varchar(20) NOT NULL,
  PRIMARY KEY (`id_contato`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Extraindo dados da tabela `contatos`
--

INSERT INTO `contatos` (`nome`, `fone`, `email`, `id_contato`, `grupo`) VALUES
('Gisela Cesario', '(82)9190-8890', 'gicesarujo@hotmail.com', 4, 'Amigos'),
('Zé ', '(82)9999-9999', 'ze@hotmail.com', 5, 'Trabalho '),
('Maria', '(82)1212-1313', 'maria@hotmail.com', 6, 'amigos'),
('Vovó', '(64)9999-9999', 'vovo@hotmail.com', 7, 'familia'),
('Fernanda', '(82)8282-2828', 'nanda@hotmail.com', 8, 'Escola');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
